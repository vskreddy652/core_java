
class Employee9{
	int emp_id;
	String name;
	Employee9()
	{
		emp_id = 10;
		name = "kumar";
	}
	
	Employee9(Employee9 eobj)
	{
		emp_id = eobj.emp_id;
		name = eobj.name;
	}
	
	Employee9(int pemp_id, String pname)
	{
		emp_id = pemp_id;
		name = pname;
	}
	
	void display()
	{
		System.out.println(emp_id+"\t"+name);
	}
}

public class ConstructorTypes {
	public static void main(String[] args) {
		Employee9 obj = new Employee9(20,"name3");
		obj.display();
		
		Employee9 obj1 = new Employee9(30,"name4");
		obj1.display();
		
		Employee9 nobj = new Employee9(obj);
		nobj.display();
	}
}
