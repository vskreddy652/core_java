
class Employee{
	int emp_id;
	String name;
	Employee()
	{
		emp_id = 10;
		name = "kumar";
	}
	
	void display()
	{
		System.out.println(emp_id+"\t"+name);
	}
}

public class ClassDemo9 {
	public static void main(String[] args) {
		Employee obj = new Employee();
		obj.display();
		
		Employee obj1 = new Employee();
		obj1.display();
	}
}
