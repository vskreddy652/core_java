
public class ForLoop1 {
	public static void main(String[] args) {
		
		int num = 68;
		boolean is_prime = true;
		
		for(int i=2;i<(num/2);i++)
		{
			System.out.println("iteration no. "+i);
			if(num%i==0)
			{
				is_prime = false;
				break;
			}
		}
		
		if(is_prime)
		{
			System.out.println(num+" is a prime");
		}
		else
		{
			System.out.println(num+" is not a prime");
		}
		/*
		int i = 0;
		for(double k=50;k>=20;k=k-0.2)
		{
		System.out.println(k);
		i++;
		}
		
		System.out.println("No. of iterations:"+i);
		*/
	}
}
