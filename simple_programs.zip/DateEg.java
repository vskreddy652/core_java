import java.util.Date;
import java.time.LocalDate;
import java.util.StringTokenizer;

public class DateEg {
	public static void main(String[] args) {
		StringTokenizer stoken = new StringTokenizer("fddfs,dbhd,dvdasyu,dfasgd",",");
		
		while(stoken.hasMoreTokens())
		{
			System.out.println("Next Token: "+stoken.nextToken());
		}
		
		double tan30 = Math.tan(30);
		System.out.println("Tan 30 is "+tan30);
		
		Date today = new Date();
		System.out.println(today);

		LocalDate localDate = LocalDate.now();
		System.out.println(localDate);
	}
}
