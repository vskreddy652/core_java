
public class ConditionExample2 {
	public static void main(String[] args) {
		int marks = 55;
		
		if(marks<35)
		{
			System.out.println("student has failed with "+marks+" marks");
		}
		else if(marks>=35 && marks<=50)
		{
			System.out.println("student has attained grade 3 with marks "+marks);
		}
		else if(marks>50 && marks<=60)
		{
			System.out.println("student has attained grade 2 with marks "+marks);

		}
		else if(marks>60 && marks<=70)
		{
			System.out.println("student has attained grade 1 with marks "+marks);

		}		
		else
		{
			System.out.println("student has attained distinction , with "+marks+" marks");
		}
	}
}
