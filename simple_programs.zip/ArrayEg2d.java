
public class ArrayEg2d {
	public static void main(String[] args) {
		double temperature[][] = {{12.3,31.1},{23.5,16,4},{31.3,16.8}};
		
		double max = temperature[0][0];
		for(int i=0;i<temperature.length;i++)
		{
			for(int j=0;j<temperature[0].length;j++)
			{
				if(max<temperature[i][j])
				{
					max = temperature[i][j];
				}
				System.out.print(temperature[i][j]+"\t");
			}
			System.out.println();
		}
		
		System.out.println("Max "+max);
	}
}
