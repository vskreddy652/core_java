
class StaticExample{
	int val1;
	static int val2;
	
	void met1(){
		System.out.println("non static met1()");
		//met2();
	}
	
	static void met2(){
		System.out.println("static met2()");
		StaticExample obj = new StaticExample();
		obj.met1();
	}
}

public class StaticKeyword {
	public static void main(String[] args) {
		//StaticExample.val1 = 10; //compile error
		StaticExample.val2 = 100;
		//StaticExample.met1();
		
		StaticExample.met2();
		
		StaticExample se1,se2;
		se1 = new StaticExample();
		se2 = new StaticExample();
		
		se1.val1 = 200;
		se2.val1 = 300;
		
		
		System.out.println("se1.val1="+se1.val1);
		System.out.println("se2.val1="+se2.val1);

		System.out.println();
		System.out.println("se1.val2="+se1.val2);
		System.out.println("se2.val2="+se2.val2);
	}
}
