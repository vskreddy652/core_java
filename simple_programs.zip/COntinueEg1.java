
public class COntinueEg1 {
	public static void main(String[] args) {

		int i=0;
		//continue example
		while(i<20)
		{
			if(i%3==0)
			{
				i++;
				continue;
			}

			System.out.println(i);
			i++;
		}
		
		System.exit(0);
		int arr[]= {10,23,14,9,43};
		
		for(int val:arr)
		{
			System.out.println(val);
		}
		
		//nested for example
		/*for(int k=1;k<=5;k++)
		{
			for(int m=1;m<=10;m++)
			{
				System.out.println(k+"X"+m+"="+(k*m));
			}
			
			System.out.println("-----------------------");
		}
		
		
		//continue example
		for(int i=0;i<20;i++)
		{
			if(i%3==0)
			{
				continue;
			}
			System.out.println(i);
		}
		*/
	}
}
