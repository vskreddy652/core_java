
public class ConditionExample1 {
	public static void main(String[] args) {
		int marks = 50;
		
		if(marks<35)
		{
			System.out.println("sutdent has failed with "+marks+" marks");
		}
		else
		{
			System.out.println("student has passed the exam, with "+marks+" marks");
		}
	}
}
