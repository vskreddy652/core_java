
class Vehicle{
	int i;
	
	Vehicle(int i)
	{
		this.i = i;
	}
	
	void setI(int i)
	{
		this.i = i;
	}
	
	int getI()
	{
		return i;
	}
}

public class SwitchCaseEg {
	public static void main(String[] args) {
		
		int val = 3;
		
		switch(val)
		{
			case 1:
				System.out.println("one ");
				break;
			case 2:
				System.out.println("two ");
				break;	
			case 3:
				System.out.println("three ");
				break;
			default:
				System.out.println("default int");
		}
		
		char c = 'b';
		switch(c)
		{
			case 'a' + 1:
				System.out.println("a ");
				break;
			case 'b' + 1:
				System.out.println("b ");
				break;	
			case 'c' + 1:
				System.out.println("c ");
				break;
			default:
				System.out.println("default char");
		}		
		
		String str = "aaa";
		switch(str)
		{
			case "aaa":
				System.out.println("aaa string");
				//break;
			case "bbb":
				System.out.println("bbb string ");
				break;	
			case "ccc":
				System.out.println("ccc string ");
				break;
			default:
				System.out.println("default string");
		}		
		
		/*
		Vehicle vh = new Vehicle(1);
		switch(vh)//compiler error: Cannot switch on a value of type Vehicle. Only convertible int values, strings or enum variables are permitted
		{
			case "aaa":
				System.out.println("aaa string");
				break;
			case "bbb":
				System.out.println("bbb string ");
				break;	
			case "ccc":
				System.out.println("ccc string ");
				break;
			default:
				System.out.println("default string");
		}*/
	}
}
