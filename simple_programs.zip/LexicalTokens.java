
public class LexicalTokens {
	public static void main(String[] args) {
		int/*keyword*/ i/*identifier*/,j;/*separator*/
		int k;
		i=10;/* = operator*/
		j=20;
		k = i+j; //operator
		
		System.out.println("The result is: "+k);
	}
}
