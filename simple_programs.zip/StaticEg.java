
class Abcd{
	static int pan_number;
	int empid;
	
	static void met1(){ 
		//Abcd obj = new Abcd();
		//obj.met2();
		empid = 10;
		System.out.println("static void met1()");
	}
	
	void met2(){
		met1();
		System.out.println("void met2()");
	}
}

public class StaticEg {
	public static void main(String[] args) {
		Abcd.met1();
		//Abcd.met2();
	}
}
