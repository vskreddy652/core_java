
class Product{
	private String name;
	private int quantity;
	private float price;
	
	public Product(){}
	
	public Product(String name, int quantity, float price) {
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}

	public void display() {
		System.out.println("Product [name=" + name + ", quantity=" + quantity + ", price=" + price + "]");
	}
	
	
}

public class ArrayOfobjects {
	public static void main(String[] args) {
		Product pObj[]=new Product[5];
		pObj[0] = new Product("TShirt",25,20);
		pObj[1] = new Product("SSVessel",15,8);
		pObj[2] = new Product("Chair",20,15.5f);
		pObj[3] = new Product("Sofa Set",5,80);
		pObj[4] = new Product("Curtains",15,13);
		
		displayAllProducts(pObj);
		
		for(int i=0;i<pObj.length;i++)
		{
			for(int j=0;j<pObj.length-i-1;j++)
			{
				if(pObj[j].getPrice()>pObj[j+1].getPrice())
				{
					Product tpObj = pObj[j];
					pObj[j] = pObj[j+1];
					pObj[j+1] = tpObj;
				}
			}
		}
		
		displayAllProducts(pObj);
		
	}
	
	static void displayAllProducts(Product[] pObj)
	{
		System.out.println("List of Products:");
		for(Product tObj:pObj)
		{
			tObj.display();
		}
	}
}
