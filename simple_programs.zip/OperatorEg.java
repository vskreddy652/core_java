
public class OperatorEg {
	public static void main(String[] args) {
		int x,y,z;
		x = 10; 
		y = 25;
		z = x+y;
		System.out.println("Value of z is "+z);
		
		double d1, d2;
		float temperature = (float)3.5;
		
		System.out.println(x*y+z/x);
		
		System.out.println("x<y:"+(x<y));
		
		if((z>=45))
		{
			System.out.println("This is in if condition");
		}
		
		x = 36;
		
		if(x>=20 && x<=30)
		{
			System.out.println("x is b/n 20 & 30");
		}
		
		int a = 4,b = 8;
		System.out.println("(a|b): "+(a|b));
		System.out.println("(a&b): "+(a&b));
		
		int c = a>10?a:b;
		System.out.println("c="+c);
		
		a += 10;
		
		a += 10+b;
		a = a+ (10+b);
	}
}
