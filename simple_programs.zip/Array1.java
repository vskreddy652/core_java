
public class Array1 {
	public static void main(String args[])
	{
		
		int x= 3;
		
		if(x==1)
		{
			sysout
		}
		
	}
}
