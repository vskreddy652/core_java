
public class Test {
	
	public static void main(String args[])
	{
		int x;
		x = 20;
		
		int y = 30, result;
		result = x+y;
		
		System.out.println("Hello World "+result);
	}
}
