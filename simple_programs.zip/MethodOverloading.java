
public class MethodOverloading {
	public static void main(String[] args) {
		System.out.println(add(10,20));
		
		float z = add(12.3f,15.6f);
		System.out.println(z);
	}
	
	static int add(int i, int j)
	{
		System.out.println("static int add(int i, int j)");
		return i+j;
	}

	/*
	static void add(int i, int j)
	{
		System.out.println("static int add(int i, int j)");
		return;
	}*/
	
	static int add(int i, int j, int k)
	{
		System.out.println("static int add(int i, int j, int k)");
		return i+j+k;
	}
	
	static float add(float i, float j)
	{
		System.out.println("static float add(float i, float j)");
		return i+j;
	}
}
