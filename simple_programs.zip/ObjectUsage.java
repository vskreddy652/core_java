class Department{
	Employee8 eobj[];
	int nEmp;
	Department()
	{
		eobj = new Employee8[10];
		nEmp = 0;
	}
	
	boolean addEmployee(Employee8 e8)
	{
		boolean added = false;
		if(nEmp<10)
		{
			eobj[nEmp] = e8;
			nEmp++;
			added = true;
		}
		return added;
	}
	
	Employee8 getEmployee(int index)
	{
		Employee8 temp = null;
		if(index<nEmp)
		{
			temp = eobj[index];
		}
		return temp;
	}
	
	void displayEmployees()
	{
		for(Employee8 emp:eobj)
		{
			if(emp!=null)
			{
				emp.display();
			}
		}
	}
}

class Employee8{
	int emp_id;
	String name;
	Employee8()
	{
		emp_id = 10;
		name = "kumar";
	}
	
	Employee8(Employee8 eobj)
	{
		emp_id = eobj.emp_id;
		name = eobj.name;
	}
	
	Employee8(int pemp_id, String pname)
	{
		emp_id = pemp_id;
		name = pname;
	}
	
	void display()
	{
		System.out.println(emp_id+"\t"+name);
	}
}

public class ObjectUsage {
	public static void main(String[] args) {
		Employee8 obj = new Employee8(20,"name3");
		
		Employee8 obj1 = new Employee8(30,"name4");
		
		Employee8 nobj = new Employee8(10, "name5");
		
		Department dept = new Department();
		dept.addEmployee(obj);
		dept.addEmployee(obj1);
		dept.addEmployee(nobj);
		
		dept.displayEmployees();
	}
}
