
public class ArrayEg1 {
	public static void main(String[] args) {
		//find max element
		int marks[] = {23,15,83,53,29,81,32};
		
		int max_marks = marks[0];
		for(int i=1;i<marks.length;i++)
		{
			if(max_marks<marks[i])
			{
				max_marks = marks[i];
			}
		}
		System.out.println("Max. marks:"+max_marks);

		
		//find avg value
		int avg_marks = 0;
		for(int i=1;i<marks.length;i++)
		{
				avg_marks += marks[i];
		}
		System.out.println("Avg. marks:"+(avg_marks/marks.length));
		
		//reverse
		int n = marks.length-1;
		for(int i=0;i<marks.length/2;i++)
		{
			int tmp = marks[i];
			marks[i]  = marks[n-i];
			marks[n-i] = tmp;
		}
		
		for(int element: marks)
		{
			System.out.print(element+"\t");
		}
		
		//bubble sort
		for(int i=0;i<marks.length;i++)
		{
			for(int j=0;j<marks.length-i-1;j++)
			{
				if(marks[j]>marks[j+1])
				{
					int tmp = marks[j];
					marks[j] = marks[j+1];
					marks[j+1] = tmp;
				}
			}
		}
		System.out.println("\nSorted elements are:");
		for(int element: marks)
		{
			System.out.print(element+"\t");
		}
	}
}
