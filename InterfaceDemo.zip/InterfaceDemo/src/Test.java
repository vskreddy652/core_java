
//An interface is a set of method declarations
//without method definitions
public interface Test {
public void show();

public int met1();

public void met2();
}
