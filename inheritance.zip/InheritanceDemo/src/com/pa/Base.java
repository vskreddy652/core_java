package com.pa;

public class Base
{
	private int d;
	protected int i,j;
	float z;
	//protected members can be accessed within the class and 
	//sub class, and in current package
	
	protected Base()
	{
		System.out.println("This is Base() Constructor");
	}
	
	public static void met()
	{
		System.out.println(" met() in Base");
	}	
}

