package com.pc;

import com.pb.Derived;

public class MainProgram{
	
	
	public static void main(String args[])
	{
		Derived obj = new Derived(10,20,30);
		
		//System.out.println(obj.i);
		//obj.show();
		obj.met();//Base class methods can be called from Derived class objects
	}
}
