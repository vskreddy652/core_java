package com.pb;

import com.pa.Base;

public class Derived extends Base
{
	int k;
	
	public Derived(int x,int y, int z)
	{
	System.out.println("Derived(int x,int y, int z) constructor");	
		i = x;
		j = y;
		//d = 10; //Compiler error, since d is private in Base class
		k = z;		
	}
	
	public static void met()
	{
		System.out.println(" met in Derived");
	}	
	
	public void show()
	{
		System.out.println(" values of k is:"+k);
	
		met();
	}
}

