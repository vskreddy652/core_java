class A extends C{
	
}

class B extends A{
	
}

class C extends B{
	
}


public class CyclicInheritance {

}
