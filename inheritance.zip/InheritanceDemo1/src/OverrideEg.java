class A88{
	void met()
	{
		System.out.println("A.met()");
	}
}

class B88 extends A88{
	void met()
	{
		System.out.println("B.met()");
	}
}

class C88 extends A88{
	void met()
	{
		System.out.println("C.met()");
	}
}

public class OverrideEg {
	public static void main(String[] args) {
		A88 oa = new A88();
		
		oa.met();
		
		oa = new B88();
		
		oa.met();
		
		oa = new C88();
		
		oa.met();
	}
}
