
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

import org.springframework.context.annotation.*;

class Foo {
	   public void init() {
	      // initialization logic
		   System.out.println("init() method invoked");
	   }
	   
	   public void cleanup() {
	      // destruction logic
		   System.out.println("cleanup() method invoked");
	   }
}

class Abc {
	void met()
	{
		System.out.println("Abc.met()");
	}
	
}

@Configuration
class AppConfig {
	   @Bean(initMethod = "init", destroyMethod = "cleanup" )
	   public Foo foo() {
	      return new Foo();
	   }
	   
	   @Bean 
	   public Abc createBean() {
		   System.out.println("...........");
	      return new Abc();
	   }   
}
	
	
public class Test {
	   public static void main(String[] args) {
	      ApplicationContext ctx = 
	         new AnnotationConfigApplicationContext(AppConfig.class);

	      Foo fo = ctx.getBean(Foo.class);
	      
	      //fo.init();
	      
	      Abc abean = ctx.getBean(Abc.class);
	      abean.met();
	   }
}