import org.springframework.util.SystemPropertyUtils;

public class Address {
	private String actual;
	private String suggestion;
	
	Address(){
		System.out.println("Address cons");
	}
}
