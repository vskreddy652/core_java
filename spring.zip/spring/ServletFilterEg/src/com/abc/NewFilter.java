package com.abc;
import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.*;  
  
public class NewFilter implements Filter{  
  
public void init(FilterConfig arg0) throws ServletException 
{
    System.out.println("init() in NewFilter");
}  
      
public void doFilter(ServletRequest req, ServletResponse resp,  
    FilterChain chain) throws IOException, ServletException {  
          
    PrintWriter out=resp.getWriter();  
    out.print("<br>2222222222filter is invoked before");  
          
    chain.doFilter(req, resp);//sends request to next resource  
          
    out.print("<br>222222222222222filter is invoked after");  
    
    System.out.println("doFilter() in NewFilter");
    }  

public void destroy() {
    System.out.println("destroy() in NewFilter");
    }  
} 