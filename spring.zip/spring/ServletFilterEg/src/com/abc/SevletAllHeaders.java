package com.abc;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletConfig;

/**
 *
 * @author ADMIN
 */
@WebServlet("/SevletAllHeaders")
public class SevletAllHeaders extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        //printConfigParams(getServletConfig());
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        printConfigParams(getServletConfig());
        
    }

    private void printConfigParams(ServletConfig sc)
    {
        String val = sc.getInitParameter("abc");
        //sc.getInitParameterNames(); //returns Enumerator
        System.out.println("Config param value:"+val);
    }
    
    public void processRequest(HttpServletRequest req,HttpServletResponse res) throws IOException{
    Enumeration paramNames = req.getHeaderNames(); 
    PrintWriter pw = res.getWriter();
    while(paramNames.hasMoreElements()) 
    { 
        String paramName = (String)paramNames.nextElement(); 
        pw.print(paramName+":"); 
        String paramValue = req.getHeader(paramName); 
        pw.print("<i>"+paramValue + "</i><br>"); 
    }  
    }
}