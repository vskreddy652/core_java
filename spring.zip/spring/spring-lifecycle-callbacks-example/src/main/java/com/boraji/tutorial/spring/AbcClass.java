package com.boraji.tutorial.spring;

import org.springframework.stereotype.Component;

@Component
public class AbcClass {
	void met()
	{
		System.out.println("AbcClass.met().........");
	}
}
