public class B1 {  
B1(){System.out.println("b constructor is invoked");}  
void print(){System.out.println("hello b");}  
} 