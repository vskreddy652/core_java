package com.eg;
/*
public class B {
	B() {
		System.out.println();
	}
}*/
