package com.eg;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("abean")
@Scope("prototype")
public class A{
	private String str;
	A(){}
	A(String str){
		this.str = str;
		System.out.println("A()"+str);
	}
	
	public void initBn(){
		System.out.println("initBn()...");
	}
	
	public void destroyBn(){
		System.out.println("destroyBn()...");
	}

	@Override
	public String toString() {
		return "A [str=" + str + "]";
	}
}
