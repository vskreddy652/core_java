
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

import org.springframework.context.annotation.*;

@Configuration
class TextEditorConfig {
   @Bean 
   public TextEditor textEditor(){
      return new TextEditor( spellChecker() );
   }

   @Bean 
   public SpellChecker spellChecker(){
      return new SpellChecker( );
   }
}

class TextEditor {
	   private SpellChecker spellChecker;

	   public TextEditor(SpellChecker spellChecker){
	      System.out.println("Inside TextEditor constructor." );
	      this.spellChecker = spellChecker;
	   }
	   public void spellCheck(){
	      spellChecker.checkSpelling();
	   }
	}

class SpellChecker {
	   public SpellChecker(){
	      System.out.println("Inside SpellChecker constructor." );
	   }
	   public void checkSpelling(){
	      System.out.println("Inside checkSpelling." );
	   }
	}

public class Test {
	   public static void main(String[] args) {
	      ApplicationContext ctx = 
	         new AnnotationConfigApplicationContext(TextEditorConfig.class);

	      TextEditor te = ctx.getBean(TextEditor.class);
	      te.spellCheck();
	   }
	}