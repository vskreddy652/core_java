import org.springframework.util.SystemPropertyUtils;

public class GrammarSug {
	private String actual;
	private String suggestion;
	
	GrammarSug(){
		System.out.println("GrammarSug cons");
	}
}
