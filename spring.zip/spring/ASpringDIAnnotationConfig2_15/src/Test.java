
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

class Foo{
	Foo(Bar br){}
}

class Bar{}

@Configuration
class AppConfig {
   @Bean
   public Foo foo() {
      return new Foo(bar());
   }
   @Bean
   public Bar bar() {
      return new Bar();
   }
}

public class Test {  
    	public static void main(String[] args) {
    		   ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
    		   
    		   Foo fo = ctx.getBean(Foo.class);

    		   System.out.println(fo+" object got created");
    		}
          
}  
