package com.vskreddy652.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestMain {
public static void main(String[] args) {
SpringApplication.run(SpringBootRestMain.class, args);
}
}
