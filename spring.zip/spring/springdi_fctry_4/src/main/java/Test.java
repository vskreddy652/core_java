import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*;  
  
public class Test {  
    public static void main(String[] args) {  
          
        Resource r=new ClassPathResource("applicationContext.xml");  
        BeanFactory factory=new XmlBeanFactory(r);  
          
        //We are providing the values 10 and "abcd" dynamically
        IEmployee s=(IEmployee)factory.getBean("e",38,"testingpurpose");  
        //IEmployee s=(IEmployee)factory.getBean("e"); 
        s.show();  
    }  
}
