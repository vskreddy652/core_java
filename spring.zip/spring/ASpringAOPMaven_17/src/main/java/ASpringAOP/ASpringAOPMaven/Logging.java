package ASpringAOP.ASpringAOPMaven;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Logging {
	@Before("execution(* *.set*(int))")
	public void adv()
	{
		System.out.println("before logging");
	}
	
	//AfterThrow
	@After("execution(* *.*(int))")
	public void adv1()
	{
		System.out.println("after logging");
	}
}
