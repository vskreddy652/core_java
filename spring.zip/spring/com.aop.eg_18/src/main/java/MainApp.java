import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

		Student student = (Student) context.getBean("student");

		// Student student = new Student();
		student.setName("Argumentttttt", "seconddddddddddddddddd");
		student.setAge(20);

		System.out.println("-----------------------------");
		student.getAge();
		student.getName();
		student.testExample(10);
		student.printThrowException();
	}
}