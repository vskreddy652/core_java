import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;

@Aspect
public class Logging_old {

	/**
	 * Following is the definition for a pointcut to select all the methods
	 * available. So advice will be called for all the methods.
	 */
	// @Pointcut("execution(* *.*(*))") //one argument of any type
	@Pointcut("execution(* *.*(..))") // methods starting with test
	// @Pointcut("execution(* *.*(..))")
	private void selectAll() {
	}

	/**
	 * This is the method which I would like to execute before a selected method
	 * execution.
	 */
	// @Before("selectAll()")
	// @Before("execution(* com.xyz.myapp.service.*.*(..))")
	@Before("execution(* *.*(..)) throws")
	public void beforeAdvice(JoinPoint jp) {

		System.out.println("bbbbbbbefore Advice invokedddddddddddd " + jp.getSignature().getName());

		Object ags[] = jp.getArgs();

		for (Object x : ags) {
			// below line used to retrieve first argument
			System.out.println("In b4 advice" + x);
		}
	}

	@Before("execution(* *.getA*(..))")
	public void beforeAdvice1(JoinPoint jp) {

		System.out.println("bbbbbbbefore Advice11111111 invokedddddddddddd " + jp.getSignature().getName());

		// below line used to retrieve first argument
		// System.out.println("In b4 advice"+jp.getArgs()[0]);
	}

	/**
	 * This is the method which I would like to execute after a selected method
	 * execution.
	 */
	// @After("selectAll()")
	@After("execution(* *.*(..))")
	public void afterAdvice() {
		System.out.println("after Advice1 invokedddddddddddddddd\n");
	}

	/* There can be multiple After Advices */
	/*
	 * @After("selectAll()") public void afterAdviceXYZ(){ System.out.
	 * println("after Advice 2.tttttttttttttttttttttttttttttttttttttttttttttttttt"
	 * ); }
	 */

	/*
	 * @Around("selectAll()") public void aroundAdvice(){
	 * System.out.println("This is arrrrrrrround Advice"); }
	 */

	/**
	 * This is the method which I would like to execute when any method returns.
	 */
	@AfterReturning(pointcut = "execution(* *.*(..))", returning = "retVal")
	public void afterReturningAdvice(Object retVal) {
		System.out.println("Returninggggggggggggggg:" + retVal.toString());
	}

	/**
	 * This is the method which I would like to execute if there is an exception
	 * raised by any method.
	 */
	@AfterThrowing(pointcut = "selectAll()", throwing = "ex")
	public void AfterThrowingAdvice(IllegalArgumentException ex) {
		System.out.println("There has been an exception: " + ex.toString());
	}

}