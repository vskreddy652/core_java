package com.inr;
class OuterClass1{

	public void met1()
	{
		System.out.println("met1() in InnerClass1");
	}
}

public class NamedObj {
	
	static void met2(OuterClass1 ico)
	{
		ico.met1();
	}
	
	public static void main(String args[])
	{
		//Inner class which is Derived class of OUterClass1
		//we are overriding met1
		//It is ANonymous class
		OuterClass1 obj = new OuterClass1(){
			public void met1(){
				System.out.println("met1() in Anonymous class");
			}
		};
		
		obj.met1();
		
		//anonymous inner class as parameter
		met2(new OuterClass1(){
			public void met1(){
			System.out.println("class as parameter");
			}
		});
	}
}