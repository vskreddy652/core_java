package com.inr;

class InnerClass{

	public void met1()
	{
		System.out.println("met1() in InnerClass");
	}
}

public class AnonymousObj1 {
	public static void main(String args[])
	{
		final int i=8;
		//Anonymous Inner class and Anonymous object
		new InnerClass(){
			@Override
			public void met1(){
				System.out.println("met1() in Anonymous class"+i);
			}
		}.met1();
	}
}
