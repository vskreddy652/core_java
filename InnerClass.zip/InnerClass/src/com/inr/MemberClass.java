package com.inr;
public class MemberClass {
	public static void main(String[] args) {
		// first way:
		OC2 a = new OC2();
		
		OC2.IC2 b = a.new IC2();
		b.print(); // outputs 3
		
		// another way:
		OC2.IC2 obj = new OC2().new IC2();
		obj.print(); // outputs 3
	}
}

class OC2 {
	private int x = 1;
	float ft = 1.3f;
	
	//Inner class
	//Inner class can be protected, also
	public class IC2 
	{
		public int y = 2;
		public void print() {System.out.println(x+y+ft);}
	}

	/*public void xyz(){
		y = 10; //private members of inner class not directly accessible
	}*/

}

