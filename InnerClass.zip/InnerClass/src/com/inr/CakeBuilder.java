package com.inr;

public class CakeBuilder {
	private int y;
	
	public CakeBuilder addY(int y)
	{
		this.y = y;
		
		return this;
	}
	
	//inner class
	public class Cake{
		private int x;
		
		//inner class has access to all members of outer class(even private members of outer class)
		private Cake(CakeBuilder cb){ x = cb.y;}
	}
	
	public Cake build()
	{
		return new Cake(this);
	}
}
