package com.inr;

class Check{
	public void met(){}
}

public class ReturnInnerClass {
	private static Object myMet() {
		//Anonymous derived class of Check, which overrides met()
		return new Check(){ 
			public void met(){
				System.out.println("This is to Test");
				}
			};
	}
	
	public static void main(String[] args) {
		Object obj = ReturnInnerClass.myMet();
		((Check)obj).met();
	}
}
