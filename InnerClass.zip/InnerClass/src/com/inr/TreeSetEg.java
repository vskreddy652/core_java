package com.inr;

import java.util.*;

public class TreeSetEg {
	public static void main(String[] args) {
		Comparator<String> cs = new Comparator<String>(){
			public int compare(String str1, String str2)
			{
				return str2.compareTo(str1);
			}
		};
		TreeSet<String> tss = new TreeSet<String>(new Comparator<String>(){
			public int compare(String str1, String str2)
			{
				return str2.compareTo(str1);
			}
		});
		tss.add("fdsfsdfsd");
		tss.add("zzzzz");
		tss.add("eeeeeeeeee");
		tss.add("qqqqqqqqq");
		tss.add("aaaaaaa");
		
		for(String str: tss)
		{
			System.out.println(str);
		}
	}
}

