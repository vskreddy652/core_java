package com.inr1;


class Xyz{
	class Pqr{
		class Mno{
			
		}
	}
}

public class MemberClass2 {
public static void main(String[] args) {
	OC2.IC2 obj = new OC2().new IC2();

	obj.print();
}
}

class OC2 {
	private static int x = 1;
	float ft = 1.3f;
	
	//Inner class
	//Inner class can be protected, also
	public class IC2 
	{
		public int y = 2;
		public void print() {System.out.println(x+y+ft);}
	}

/*public void xyz(){
	y = 10; //private members of inner class not directly accessible
}*/

}

