package com.inr1;

public class StaticInnerClass {

	public static void main(String[] args) {
			OC9.IC2 obj = new OC9.IC2();
			obj.print();
		}
}

class OC9 {
	private static int x = 1;
	float ft = 1.3f;
	//Inner class can be protected, also
	static public class IC2 
	{
		public static int y = 2;
		public void print() {System.out.println(x+y);}
	}
}


