package com.p2.sp;

public class Xyz {
	void print()
	{
		System.out.println("com.p2.sp.Xyz.print() invoked...");
	}
}
