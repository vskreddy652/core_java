package com.p2;

public class Qrs {
	public void met()
	{
		System.out.println("com.p2.Qrs.met() invoked...");
	}
}
