package com.pkg1;

import com.pkg.*;
import java.util.*;

public class Mno {
	public static void main(String[] args) {
		Abc obj = new Abc();
		obj.met();
		new Pqr().display();
	}
}
