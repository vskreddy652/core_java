package com.pkg;

public class Pqr {
	public void display()
	{
		new Abc().met();
		System.out.println("display() in Pqr");
		System.out.println(Bcd.display());
	}
}
