package com.pkg;

public class Abc {
	public void met()
	{
		System.out.println("met() in com.pkg.Abc");
	}
}

class Bcd {
	public static String display()
	{
		return "Hello, how are you?";
	}
}
