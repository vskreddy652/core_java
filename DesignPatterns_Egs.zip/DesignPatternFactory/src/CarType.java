public enum CarType {
    SMALL, SEDAN, LUXURY
}