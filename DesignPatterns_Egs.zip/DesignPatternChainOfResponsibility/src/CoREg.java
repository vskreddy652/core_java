class Request{
	int value;
	String desc;
	
	public Request(int value, String desc)
	{
		this.value = value;
		this.desc = desc;
	}
	
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}	
}

abstract class Handler{
	Handler scsr;
	
	public void setSuccessor(Handler scsr)
	{
		this.scsr = scsr;
	}
	
	public abstract void handleRequest(Request rqs);
}

class ConcreteHandlerOne extends Handler{
	public void handleRequest(Request rqs)
	{
		if(rqs.getValue()<0)
		{
			System.out.println(" Handling Request details<0:"+rqs.getValue()+" "+rqs.getDesc());
		}
		else
		{
			scsr.handleRequest(rqs);
		}
	}
}

class ConcreteHandlerTwo extends Handler{
	public void handleRequest(Request rqs)
	{
		if(rqs.getValue()>0)
		{
			System.out.println("Handling Request details>0:"+rqs.getValue()+" "+rqs.getDesc());
		}
		else
		{
			scsr.handleRequest(rqs);
		}
	}
}

class ConcreteHandlerThree extends Handler{
	public void handleRequest(Request rqs)
	{
		if(rqs.getValue()==0)
		{
			System.out.println("Handling Request details==0:"+rqs.getValue()+" "+rqs.getDesc());
		}
		else
		{
			scsr.handleRequest(rqs);
		}
	}
}

public class CoREg {
	public static void main(String[] args) {
		/* Best example
		 *  Say if you want to withdraw 2200 Rs, and ATM has 1000, 500 and 100 rupee notes. 
		 *  As per chain of responsibility the request would be sent to object that dispenses 1000 rs note. 
		 *  If 1000 ruppee notes are NOT available then it would be sent to an object that dispenses 500 rs note. 
		 *  The 500Rs object decides to dispense 4 notes and then 100 rs object would be asked to handle the rest. 
		 *  Advantage is, eventhough there are no 1000 rs not avaialble, your req would be still handled by other objects like 500 and 100.
		 */
		Handler h1 = new ConcreteHandlerOne();
		Handler h2 = new ConcreteHandlerTwo();
		Handler h3 = new ConcreteHandlerThree();
		
		h1.setSuccessor(h3);
		h3.setSuccessor(h2);
		
		Request req = new Request(25, "Test Purpose");
		h1.handleRequest(req);
		
		Request reqn = new Request(-25, "Test Purpose");
		h1.handleRequest(reqn);
	}
}
