// Memento Design Pattern
// Used stores an objects state at a point in time
// so it can be returned to that state later. It
// simply allows you to undo/redo changes on an Object

// Memento Design Pattern Tutorial

import java.util.ArrayList;

//Actual object, whose state need to be persisted
class Memento {
// The article stored in memento Object
private String article;
// Save a new article String to the memento Object
public Memento(String articleSave) { article = articleSave; }
// Return the value stored in article
public String getSavedArticle() { return article; }
}


// Memento Design Pattern
//Note, object(s) of Originator class need to be in Memento
class Originator{
	
	private String article;

	// Sets the value for the article
	
	public void set(String newArticle) { 
		System.out.println("From Originator: Current Version of Article\n"+newArticle+ "\n");
	    this.article = newArticle; 
	}

	// Creates a new Memento with a new article
	
	public Memento storeInMemento() { 
	    System.out.println("From Originator: Saving to Memento");
	    return new Memento(article); 
	}
	   
	// Gets the article currently stored in memento
	
	public String restoreFromMemento(Memento memento) {
		   
		article = memento.getSavedArticle(); 
	       
		System.out.println("From Originator: Previous Article Saved in Memento\n"+article + "\n");
		
		return article;
	   
	}
	
}

class Caretaker {
   
	// Where all mementos are saved
	
	ArrayList<Memento> savedArticles = new ArrayList<Memento>();

	// Adds memento to the ArrayList
	
	public void addMemento(Memento m) { savedArticles.add(m); }
   
	// Gets the memento requested from the ArrayList
	
	public Memento getMemento(int index) { return savedArticles.get(index); }
} 


class MementoExample{
	public static void main(String args[])
	{
		  // Create a caretaker that contains the ArrayList
		   // with all the articles in it. It can add and
		   // retrieve articles from the ArrayList
		   Caretaker caretaker = new Caretaker();

		Originator originator = new Originator();
   		int saveFiles = 0, currentArticle = 0;
originator.set("This is first Text........1........");
                 
                // Add new article to the ArrayList
                caretaker.addMemento( originator.storeInMemento() );
                 
                // saveFiles monitors how many articles are saved
                // currentArticle monitors the current article displayed
                
                originator.set("This is second Text........2........");
                
                // Add new article to the ArrayList
                caretaker.addMemento( originator.storeInMemento() );
                 
                // saveFiles monitors how many articles are saved
                // currentArticle monitors the current article displayed

                 
                saveFiles++;
                currentArticle++;

//undo

currentArticle--;

                        // Get the older article saved and display it in JTextArea

                        String txt = originator.restoreFromMemento( caretaker.getMemento(currentArticle) );
                        System.out.println("After Undo:"+txt);

//redo
 currentArticle++;
                    
                        String txt1 = originator.restoreFromMemento( caretaker.getMemento(currentArticle) );

                        System.out.println("After Redo:"+txt1);
	}
}