public class MainProgram {
 
	public static void main(String[] args) {
		HeadHunter hh = new HeadHunter();
		hh.registerObserver(new JobSeeker("Rama"));
		hh.registerObserver(new JobSeeker("Krishna"));
		hh.registerObserver(new JobSeeker("Kiran"));
		hh.registerObserver(new JobPortal("Naukri.com"));
 
		//Each time, a new job is added, all registered job seekers will get noticed.
		hh.addJob("Analyst Job");
		hh.addJob("Software Programmer Job");
	}
}