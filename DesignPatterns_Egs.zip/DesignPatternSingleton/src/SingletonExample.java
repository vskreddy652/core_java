class Abc {
	private static int objCount = 0;
	
	//step 3
	private static Abc obj;
	
	//step 1
	private Abc(){ System.out.println("This is Constructor");}
	
	//step 2
	public static synchronized Abc createInstance(){
		{
		if(objCount ==0)
		{
			
			objCount++;
			obj= new Abc();
			System.out.println("object created");
		}
		else
		{
			System.out.println("Returning existing object");
		}
		}
		return obj;
	}

}

public class SingletonExample {
public static void main(String[] args) {
	Abc nc = Abc.createInstance();
	Abc nc1 = Abc.createInstance();
	Abc nc2 = Abc.createInstance();
}
}