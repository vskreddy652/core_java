
public class MVCExample {
	public static void main(String[] args) {

	      //retrieve weather record from the database
	      WeatherModel model  = WeatherModel.getWeatherFromDatabase();

	      //Create a view : to print weather details
	      WeatherView view = new WeatherView();

	      WeatherController controller = new WeatherController(model, view);

	      controller.updateView();

	      //update model data
	      controller.setWeatherMinTemp(21.3f);

	      controller.updateView();
	   }


}
