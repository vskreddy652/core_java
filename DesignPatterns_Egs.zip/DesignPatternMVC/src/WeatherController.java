
public class WeatherController {
	private WeatherModel wm;
	private WeatherView wv;
	
	public WeatherController(WeatherModel wm, WeatherView wv)
	{
		this.wm = wm;
		this.wv = wv;
	}
	
	public void setWeatherCity(String wcity)
	{
		wm.setCity_name(wcity);
	}
	
	public void setWeatherMinTemp(float mntemp)
	{
		
		wm.setMin_temp(mntemp);
	}
	
	public void setWeatherMaxTemp(float mxtemp)
	{
		
		wm.setMax_temp(mxtemp);
	}
	
	public void updateView(){				
	      wv.printWeatherDetails(wm.getCity_name(), wm.getMin_temp(), wm.getMax_temp());
	   }	
}
