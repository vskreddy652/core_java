
public class WeatherModel {
private String city_name;
private float min_temp, max_temp;

public String getCity_name() {
	return city_name;
}
public void setCity_name(String city_name) {
	this.city_name = city_name;
}
public float getMin_temp() {
	return min_temp;
}
public void setMin_temp(float min_temp) {
	this.min_temp = min_temp;
}
public float getMax_temp() {
	return max_temp;
}
public void setMax_temp(float max_temp) {
	this.max_temp = max_temp;
}

public static WeatherModel getWeatherFromDatabase(){
	   WeatherModel wmObj = new WeatherModel();
	   wmObj.setCity_name("Bangalore");
	   wmObj.setMin_temp(19.4f);
	   wmObj.setMax_temp(29.1f);
   return wmObj;
}
}
