
public class WeatherView {
	void printWeatherDetails(String city, float min_temp, float max_temp)
	{
		System.out.println("Weather details of city:"+city);
		System.out.println("Min temperature:"+min_temp);
		System.out.println("Max temperature:"+max_temp);
	}
}
