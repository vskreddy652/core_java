interface IVideo {
   void displayThumbnail();
   void playVideo();
}

class Video implements IVideo {

   private String fileName;

   public Video(String fileName){
      this.fileName = fileName;
   }

   @Override
   public void displayThumbnail() {
      loadVideoFromStorage();
      System.out.println("Displaying Thumbnail of " + fileName);
   }

   private void loadVideoFromStorage(){
      System.out.println("Loading actual video... " + fileName);
   }

   @Override
   public void playVideo()
   {
      loadVideoFromStorage();
   }
}

class ProxyVideo implements IVideo{

   private Video objVideo;
   private String fileName;

   public ProxyVideo(String fileName){
      this.fileName = fileName;
   }

   @Override
   public void displayThumbnail() {
      String thumbnail_name = fileName+"_thumbnail.jpg";
      System.out.println("Display Thumbnail Image..."+thumbnail_name);
   }

   @Override
   public void playVideo() {
      objVideo = new Video(fileName);
      objVideo.playVideo();
   }
}


public class ProxyExample{
public static void main(String[] args) {
	ProxyVideo obj = new ProxyVideo("abcd.mp4");
	
	obj.displayThumbnail();
	
	obj.playVideo();
}
}
