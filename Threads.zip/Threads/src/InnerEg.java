
public class InnerEg {

}
