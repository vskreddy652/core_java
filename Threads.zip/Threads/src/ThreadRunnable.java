
public class ThreadRunnable implements Runnable{
	
	public void run()
	{
		System.out.println("some thread");
	}
	
public static void main(String args[])
{
	Thread t1 = new Thread(new ThreadRunnable());
	System.out.println("main thread");
	
	t1.start();
	
	System.out.println(System.getProperty("java.version"));
}
}
