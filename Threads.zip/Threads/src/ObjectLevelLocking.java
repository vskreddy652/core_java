
class Mno extends Thread{
	
	Mno(String tname)
	{
		setName(tname);
	}
	
	public void run()
	{
		met();
	}
	
	//make below method static for class level locking
	//without static below method performs object level locking
	public synchronized void met()
	{
		for(int i=0;i<50;i++)
		{
			System.out.println(i);
			try
			{
			Thread.sleep(100);
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}	
	}
}

public class ObjectLevelLocking {
	public static void main(String[] args) {
		new Mno("Thread1").start();
		new Mno("Thread2").start();
		new Mno("Thread3").start();
	}
}
