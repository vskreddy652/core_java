
import java.util.*;

public class SetDemo {

public static void main(String args[])
{
		ArrayList al = new ArrayList();
		al.add(32);
		al.add(15);
		
		//stores unique values only, and insertion order is not maintained
		HashSet hs = new HashSet(al);
		
		hs.add(12);
		hs.add(6);
		hs.add(12);
		hs.add(42);
		hs.add(21);
		hs.add(23);
		hs.add(63);
		
		System.out.println(" :"+hs);
		
		Iterator itr = hs.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}

		System.out.println("--------------------");
		//ListIterator not available for Set
		
		/*Enumeration enm=Collections.enumeration(hs);
		
		for(;enm.hasMoreElements();)
		{
			System.out.println(enm.nextElement());
		}*/
		
		Integer min_str = (Integer)Collections.min(hs);
		
		System.out.println("Minimum is: "+min_str);
		
		//Collections.reverse(hs);// is supported only by List, and not Set
		
	}

}
