import java.util.*;

/*
 * How to develop Java custom Collections
 * Method-1:implementing from List, and implement all methods of interface
 * Method-2:extending from a specific implementation, and 
 * Custom ArrayList 
 * 1 - can store only two copies of objects
 * 2 - expose additional required methods
 */
class MyCustomArrayList<T> extends ArrayList<T>{
	private static final long serialVersionUID = 1L;
	
	MyCustomArrayList()
	{
	}
	
	//method to add element at the end
	private boolean addElement(T obj)
	{
		boolean added = false;

		int num_of_occurrences = Collections.frequency(this, obj);

		if(num_of_occurrences<2)
		{
			added = super.add(obj);
		}
		
		return added;		
	}
	
	//method to add element at a specific index
	private boolean addElement(int index, T obj)
	{
		boolean added = false;
		int num_of_occurrences = Collections.frequency(this, obj);

		if(num_of_occurrences<2)
		{
			super.add(index, obj);
		}
		
		return added;				
	}
	
	@Override
	public T set(int index, T obj)
	{
		int num_of_occurrences = Collections.frequency(this, obj);

		T pElement = super.get(index);
		
		if(num_of_occurrences<2)
		{			
			super.set(index, obj);
		}		
		
		return pElement;
	}
	
	@Override
	public boolean add(T obj)
	{
		return addElement(obj);
	}
	
	@Override
	public void add(int index, T obj)
	{
		addElement(obj);
	}
	
	@Override
	public boolean addAll(Collection<? extends T> coll)
	{
		boolean added_all_elements = true;
		for(T element:coll)
		{
			added_all_elements = addElement(element);
		}
		
		return added_all_elements;
	}
	
	@Override
	public boolean addAll(int index, Collection<? extends T> coll)
	{
		boolean added_all_elements = true;
		for(T element:coll)
		{
			added_all_elements = addElement(index, element);
		}
		
		return added_all_elements;
	}
}

class Employee8{
	private int emp_id;
	private String name;
	
	public Employee8(int emp_id, String name) {
		super();
		this.emp_id = emp_id;
		this.name = name;
	}
	
	public int getEmp_id() {
		return emp_id;
	}
	
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee8 [emp_id=" + emp_id + ", name=" + name + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee8 other = (Employee8) obj;
		if (emp_id != other.emp_id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}

public class CustomArrayList {
	public static void main(String[] args) {
		MyCustomArrayList<String> cArrayList = new MyCustomArrayList<String>();
		cArrayList.add("abc");
		cArrayList.add("abc");
		cArrayList.add("abc");
		
		System.out.println(cArrayList);
		
		//Compatibility with existing Collection framework functionality
		HashSet<String> hss = new HashSet<String>(cArrayList);
		System.out.println(hss);
		
		MyCustomArrayList<Employee8> cArrayListE = new MyCustomArrayList<Employee8>();
		cArrayListE.add(new Employee8(1, "name1"));
		cArrayListE.add(new Employee8(1, "name1"));
		cArrayListE.add(new Employee8(1, "name1"));

		System.out.println(cArrayListE);
	}
}
