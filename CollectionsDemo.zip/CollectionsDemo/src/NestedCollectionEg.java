import java.util.*;

public class NestedCollectionEg {
	public static void main(String[] args) {
		HashMap<String, ArrayList<String>> country_cities = new HashMap<String, ArrayList<String>>();
		
		country_cities.put("India", new ArrayList<String>(Arrays.asList("Bangalore","Mumbai", "New Delhi")));
		country_cities.put("US", new ArrayList<String>(Arrays.asList("Newyork","Washington", "Sanfrancisco")));
		country_cities.put("UK", new ArrayList<String>(Arrays.asList("London","Birmingham")));

		Set<Map.Entry<String, ArrayList<String>>> smesa = country_cities.entrySet();
		for(Map.Entry<String, ArrayList<String>> mesa:smesa)
		{
			System.out.print("Country "+ mesa.getKey()+ " has cities ");
			
			for(String city:mesa.getValue())
			{
				System.out.print(city+",");
			}
			System.out.println();
		}
	}
}
