import java.util.*;

public class HashtableEg {
	public static void main(String[] args) {
		Hashtable<String, String> ht = new Hashtable<String, String>();
		ht.put("sss", "value4");
		ht.put("sss555", "value2");
		ht.put("sss333", "value1");
		ht.put("sss111", "value3");
		
		Set<Map.Entry<String,String>> sme = ht.entrySet();
		
		for(Map.Entry<String,String> mess: sme)
		{
			System.out.println(mess.getKey()+"\t"+mess.getValue());
		}
	}
}
