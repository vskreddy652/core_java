import java.util.*;

class Product9{
	private String name;
	private float price;
	
	@Override
	public String toString() {
		return "Product [name=" + name + ", price=" + price + "]";
	}
	public Product9(String name, float price) {
		super();
		this.name = name;
		this.price = price;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}

public class LinkedListDemo9 {
	public static void main(String[] args) {
		LinkedList<Product9> llp = new LinkedList<Product9>();
		
		llp.add(new Product9("item1", 24.3f));
		llp.add(new Product9("item2", 30));
		llp.add(new Product9("item3", 10));
		
		for(Product9 prod:llp)
		{
			System.out.println(prod);
		}
		
		System.out.println("-------------------------");
		llp.remove(2);
		
		for(Product9 prod:llp)
		{
			System.out.println(prod);
		}
	}
}
