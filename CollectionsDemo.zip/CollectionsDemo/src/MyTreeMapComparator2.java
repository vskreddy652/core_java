import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Collections;
 
class EMId{
	private int id;
	private String mnf_name;
	
	public EMId(int id, String mnf_name) {
		super();
		this.id = id;
		this.mnf_name = mnf_name;
	}
	public int getId() {
		return id;
	}

	public String getMnf_name() {
		return mnf_name;
	}
}

public class MyTreeMapComparator2 {
     
    public static void main(String a[]){
    	MyComp99 comp_obj = new MyComp99();
     	TreeMap<EMId, String> hm = new TreeMap<EMId, String>(comp_obj);

     	
        //add key-value pair to TreeMap
        hm.put(new EMId(23,"fsfds"), "language");
        hm.put(new EMId(12,"mhgdgd"), "machine");
        hm.put(new EMId(18,"gfdgdfg"),"country");
        hm.put(new EMId(81,"fhdsifud"),"ksjfhgikure");

        System.out.println("Value: "+hm.get("ajfdshfsf"));
        Set<Map.Entry<EMId, String>> s= hm.entrySet();
		Iterator<Map.Entry<EMId, String>> itr1 = s.iterator();
		int i=0;
		while(itr1.hasNext())
		{//Entry is inner interface in Map interface
			
			Map.Entry<EMId, String> me = itr1.next();
			System.out.println("\nKey:"+me.getKey()+" "+"\nvalue:"+me.getValue());
		}
    }
}
    

//Here String is type of the Key object
class MyComp99 implements Comparator<EMId>{
    public int compare(EMId em1, EMId em2) {
    	return em1.getId()-em2.getId();
    }
}