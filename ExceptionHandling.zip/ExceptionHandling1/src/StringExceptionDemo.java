
public class StringExceptionDemo {
	public static void main(String[] args) {
		String str = "Hello How r u?";
		
		char c = str.charAt(str.length()+2);
		
		System.out.println("char is "+c);
	}
}
