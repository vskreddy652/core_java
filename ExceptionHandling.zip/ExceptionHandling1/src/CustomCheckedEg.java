
class SomeCheckedException extends Exception
{
	SomeCheckedException(String msg)
	{
		super(msg);
		
		System.out.println("Constructor ");
	}
}

public class CustomCheckedEg {
	public static void main(String args[])
	{
		//since SomeCheckedException is Checked Exception
		//it is mandatory to handle it or further throws it
		try{
		int val = 0;
		
		System.out.println("Before throwing exception");
	
		if(val == 0)
		{
			SomeCheckedException sre = new SomeCheckedException("test message");
			throw sre;
		}
		
		System.out.println("After throwing exception");
		}catch(Exception et){
			System.out.println("Exception has occurred.............");
		}
	}
}

