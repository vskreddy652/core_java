
public class UnCheckedExceptionEg2 {
	public static void main(String[] args){
		met();
	}
	
	static void met()
	{
		try{
			int arr[] = new int[10];
			arr[2] = 25;
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			ae.printStackTrace();
		}
	}
}
