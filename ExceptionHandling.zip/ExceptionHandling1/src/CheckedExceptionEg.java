
public class CheckedExceptionEg {
	public static void main(String[] args){
		try {
			met();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	static void met() throws Exception
	{
		System.out.println("Before throwing an Exception");
		throw new Exception("Sample Exception");
		//java.io.IOException, java.sql.SQLException
		//System.out.println("After throwing an Exception");
	}
}
