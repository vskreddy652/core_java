
// Java code for Stream filter 
// (Predicate predicate) to get a stream 
// consisting of the elements of this 
// stream that match the given predicate. 
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream; 

class Abcd99{
	static void met(int x)
	{
		System.out.println(x);
	}
}
public class StreamsEg { 

	// Driver code 
	public static void main(String[] args) 
	{ 

		// Creating a list of Integers 
		List<Integer> list = Arrays.asList(3, 4, 15, 6, 12, 20); 
		list.forEach(System.out::println);
		System.out.println("------------------------");
		//method 2
		//above can be split into two statements as well
		//filter() /* Functional Programming */
		//list.stream().filter((num) -> num % 5 == 0).forEach(System.out::println);
		list.stream().filter((num) -> num % 5 == 0).forEach(Abcd99::met);
		/*Stream<Integer> strm = list.stream().filter((num) -> {return num % 5 == 0;});
		strm.forEach(System.out::println); 
		
		if(strm.allMatch((num) -> {return num % 5 == 0;}))
		{
			System.out.println("All elements in stream are divisible by 5");
		}
		else
		{
			System.out.println("Some elements in stream are not divisible by 5");
		}*/
		
		//System.out.println("Number of elements in Stream is "+strm.count());
	} 
} 
