
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;


public class FilterStreamobjectsN5{
  public static void main(String[] argv){
    List<Person> persons = Arrays.asList(new Person("Joe", 12), new Person("", 22), new Person("J", 21), new Person("Jim", 34), new Person("John", 23));

    Stream<String> all_firstnames = persons.stream().filter(p -> p.getAge() > 18)
    		.map(obj -> obj.getFirstName()).sorted((str1, str2)-> str2.compareTo(str1));
    //.count()
    
    Optional<String> strr = persons.stream().filter(p -> (p.getAge() > 18 && p.getAge() < 20))
    		.map(obj -> obj.getFirstName()).reduce(
    				(word1, word2)-> {return word1.length() > word2.length()? word2 : word1;});

    Optional<Person> tp = persons.stream().filter(p -> (p.getAge() <10 || p.getAge()>30))
            .reduce(( p1, p2) -> {return p1.getAge() > p2.getAge() ? p1 : p2;});

    if(tp.isPresent())
    {
    	System.out.println("Str is: "+tp.get());
    }
    else
    {
    	//add code to throw appropriate Exception or takecare of this scenario
    }
    //personsOver18.forEach(p -> System.out.println(p.getFirstName()));

    /*all_firstnames.forEach(System.out::println);
    persons.forEach(System.out::println);
    */
  }
}

class Person {
    private String firstName;
    private String lastName;
    private int age;

    public Person(String firstName) {
        this.firstName = firstName;
    }

    public Person(String firstName, int age) {
        this.firstName = firstName;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
      return "Person [firstName=" + firstName + ", lastName=" + lastName
          + ", age=" + age + "]";
    }
    
}
